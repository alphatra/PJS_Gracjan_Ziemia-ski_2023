package com.mycompany.phantomvote

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
